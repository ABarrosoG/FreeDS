#!/bin/bash

# FreeDS (C) 2023 - Script by Ivan Sanchez

if [ -z "$1" ]; then
    echo "Es necesario especificar el puerto serie a utilizar, por ejemplo:"
    echo "    ./programarESP32.sh /dev/ttyUSB0"
    exit -1
fi

if ! command -v esptool &> /dev/null; then
    echo "Necesita instalar la herramienta 'esptool' en su sistema."
    echo "Si su sistema est� basado en Debian/Ubuntu, ejecute:"
    echo "    sudo apt install esptool"
    exit -2
fi

if ! [[ -r "$1" ]] ; then
    echo "El puerto serie '$1' no se puede leer."
    echo "Establezca permisos para que su usuario pueda leer y escribir a puertos series ejecutando:"
    echo "    sudo addgroup `whoami` dialout"
    echo "(Necesitar� cerrar su sesi�n de usuario y abrir una nueva)"
    echo "Alternativamente, ejecute este script como root:"
    echo "    sudo $0 $1"
    exit -3
fi

esptool --chip esp32 \
        --port "$1" \
        --baud 460800 \
        --before default_reset \
        --after hard_reset erase_flash

esptool --chip esp32 \
        --port "$1" \
        --baud 460800 \
        --before default_reset \
        --after hard_reset write_flash \
        -z \
        --flash_mode dio \
        --flash_freq 80m \
        --flash_size detect 0x1000 bootloader.bin 0x8000 partitions.bin 0xe000 boot_app0.bin 0x10000 firmware.bin 0x310000 littlefs.bin